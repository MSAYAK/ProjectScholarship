package com.lnt.mvc.dao;

import java.util.List;

import com.lnt.mvc.model.Registration;
import com.lnt.mvc.model.StudentRegistration;

public interface StudentRegistrationDao {
	
public void save(StudentRegistration s);




}
