package com.lnt.mvc.controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.lnt.mvc.exception.CustomException;
import com.lnt.mvc.model.Person;
import com.lnt.mvc.model.Registration;
import com.lnt.mvc.model.StudentRegistration;
import com.lnt.mvc.service.StudentRegistrationService;
@Controller

public class StudentRegistrationController {
private StudentRegistrationService studentRegistrationService;


@Autowired
//@Qualifier(value="studentRegistrationService")
public void setStudentRegistrationService(StudentRegistrationService studentRegistrationService) {
	this.studentRegistrationService = studentRegistrationService;
}


@RequestMapping(value="/student")
public String registerdetails(Model model) {
model.addAttribute("student",new StudentRegistration());

return "student";
}


@RequestMapping(value="/student/save",
method=RequestMethod.POST)
public String save(
		@ModelAttribute("student")
		@Valid StudentRegistration s,
		BindingResult result,
		Model model) {
		if(!result.hasErrors()) {
			
	
			System.out.println("I am in controller"+s);
			this.studentRegistrationService.save(s);
		}

		return "redirect:/student";

}






}